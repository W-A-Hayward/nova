"""Pose Q01-Q10 au chat (vrai Ollama) et affiche réponse obtenue vs réponse de référence de la baseline, pour comparaison manuelle."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import kb
from app.chat_graph import ask

base = json.load(open(kb.DATA / "baseline.json", encoding="utf-8"))
for q in base["qa"]:
    r = ask(q["question"])
    print(f"\n=== {q['id']} {q['question']}\n--- OBTENU ({', '.join(r['sujets'])}):\n{r['reponse']}\n--- RÉFÉRENCE:\n{q['reponse']}")
