"""Test sans Ollama: on remplace le LLM par un faux. Vérifie le câblage des graphes, le diff, les citations et le serveur."""
import json, shutil, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import kb, seed, llm  # noqa

calls = []
def fake_json(prompt):
    calls.append("json")
    if "Choisis les domaines" in prompt:
        return {"sujets": ["finance", "gouvernance"]}
    return {"claims": [{"sujets": ["finance"], "type": "proposition", "texte": "Boréal propose de reporter CR-04 et de remplacer INV-003 par une facture de 36 000 $", "date": "2026-09-30"}]}
def fake_text(prompt):
    calls.append("text")
    if "Synthétise" in prompt:
        return "Date approuvée: 22 octobre [S13], conditionnelle. Budget [S999]."
    if "Rédige en français un rapport" in prompt:
        return "Ce qui vient de changer: proposition CR-04 [N01]. Ce qui n'a PAS changé: 3 conditions ouvertes."
    return "HORS_DOMAINE" if "« technique »" in prompt else "Fait cité [S13]"
llm.ask_json, llm.ask_text = fake_json, fake_text

seed.__name__  # seed s'exécute à l'import
claims = kb.load_claims(); assert len(claims) >= 20, len(claims)
assert all(c["sujets"] for c in claims)
fs = kb.finance_summary(); print(fs)
assert "AUTORISÉ = contrat + changements approuvés = 204000" in fs and "FACTURÉ (toutes factures) = 186000" in fs and "PAYÉ = 132000" in fs
assert "LIGNE NON AUTORISÉE dans INV-003" in fs and "FACTURÉ LÉGITIME = 168000" in fs

from app.chat_graph import ask
r = ask("Quelle est la date approuvée?"); print(r["sujets"], r["reponse"])
assert r["sujets"] == ["finance", "gouvernance"] and "sources inconnues: S999" in r["reponse"]

from app.ingest_graph import ingest
before = len(kb.load_claims())
out = ingest("Courriel: Boréal propose de reporter CR-04...", "test.txt")
print(out["rapport"]); print("affectés:", out["affectes"])
assert out["source"] == "N01" and len(out["affectes"]) > 0 and len(kb.load_claims()) == before + 1
assert kb.load_claims()[-1]["statut"] == "à valider" and "N01" in kb.known_sources()
assert kb.load_claims()[:before] == claims  # baseline intacte (ajout seulement)

from fastapi.testclient import TestClient
from app.server import app
c = TestClient(app)
assert c.get("/").status_code == 200 and "Décisions" in c.get("/").text
assert c.get("/chat").status_code == 200 and c.get("/ingest").status_code == 200
assert "sujets" in c.post("/api/chat", json={"question": "x"}).json()
assert c.post("/api/ingest", data={"texte": "test"}).json()["source"] == "N02"
print("TOUS LES TESTS OK")
