"""Base de connaissances: claims en ajout seulement, règles d'autorité et calculs financiers en code."""
import json, re
from datetime import datetime
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
CLAIMS = DATA / "claims.json"

SUJETS = {
    "gouvernance": "gouvernance, échéancier, décisions de comité, responsables, portée, changements (phase 1 / phase 2)",
    "finance": "budget, contrat, demandes de changement (CR), factures, paiements",
    "technique": "architecture, hébergement des données, intégration, migration de données, performance",
    "qualite": "sécurité, accessibilité, exploitation (runbook), conditions de go-live",
}
# Un expert voit aussi les faits des domaines voisins (les faits clés traversent les sujets)
VOISINS = {"gouvernance": ["qualite", "finance"], "finance": ["gouvernance"], "technique": ["gouvernance"], "qualite": ["gouvernance"]}
MOTS = {
    "finance": ["inv-", "facture", "budget", "contrat", "cr-0", "$", "paiement"],
    "technique": ["int-101", "data-401", "perf-501", "canada central", "east us", "migration", "architecture", "adr-", "connecteur"],
    "qualite": ["sec-210", "acc-", "ops-", "runbook", "rollback", "sécurité", "accessibilité", "go-live", "audit", "retour arrière"],
    "gouvernance": ["comité", "approuv", "date", "22 oct", "15 oct", "portée", "phase", "responsable", "transition", "décision"],
}
# Règle d'autorité codée (pas laissée au LLM)
AUTORITE = {1: "décision formelle / contrat", 2: "ticket / compte rendu / transcript", 3: "courriel",
            4: "plan / rapport / registre (peut être périmé)", 5: "chat", 6: "brouillon / non fiable", None: "inconnue (à confirmer)"}
EXCLUS = {"HORS SUJET", "NON FIABLE", "ANCIEN", "CONSIGNES"}


def detect_sujets(text: str) -> list[str]:
    t = text.lower()
    found = [s for s, ws in MOTS.items() if any(w in t for w in ws)]
    return found or ["gouvernance"]


def load_claims() -> list[dict]:
    return json.loads(CLAIMS.read_text(encoding="utf-8")) if CLAIMS.exists() else []


def append_claims(new: list[dict]) -> None:
    """Ajout seulement: on ne modifie ni ne supprime jamais un claim existant."""
    allc = load_claims()
    n = len(allc)
    for i, c in enumerate(new, 1):
        c["id"] = f"C{n + i:03d}"
        c["ajoute_le"] = datetime.now().isoformat(timespec="seconds")
    CLAIMS.write_text(json.dumps(allc + new, ensure_ascii=False, indent=1), encoding="utf-8")


def known_sources() -> set[str]:
    base = json.loads((DATA / "baseline.json").read_text(encoding="utf-8"))
    return {s["id"] for s in base["sources"]} | {c["source"] for c in load_claims()}


def claims_for(sujet: str) -> list[dict]:
    return sorted((c for c in load_claims() if sujet in c["sujets"]), key=lambda c: c["date"])


def render(claims: list[dict]) -> str:
    if not claims:
        return "(aucun)"
    return "\n".join(
        f"- [{c['source']}] {c['date']} | {c['type']} | autorité: {AUTORITE.get(c.get('autorite'))} | statut: {c.get('statut', 'baseline')} | {c['texte']}"
        for c in claims)


def finance_summary() -> str:
    """Tous les montants sont calculés ici, jamais par le LLM."""
    L = json.loads((DATA / "ledger.json").read_text(encoding="utf-8"))
    ok = {c["id"] for c in L["changements"] if c["statut"] == "approuvé"}
    autorise = L["contrat"] + sum(c["montant"] for c in L["changements"] if c["statut"] == "approuvé")
    lignes = [(f, l) for f in L["factures"] for l in f["lignes"]]
    facture = sum(l["montant"] for _, l in lignes)
    non_aut = [(f["id"], l) for f, l in lignes if l["ref"] and l["ref"] not in ok]
    paye = sum(l["montant"] for f, l in lignes if f["statut"] == "payée")
    out = [f"Contrat initial: {L['contrat']} $ [{L['contrat_source']}]",
           *[f"{c['id']}: {c['montant']} $ {c['statut']} [{c['source']}]" for c in L["changements"]],
           f"AUTORISÉ = contrat + changements approuvés = {autorise} $",
           f"FACTURÉ (toutes factures) = {facture} $", f"PAYÉ = {paye} $"]
    for fid, l in non_aut:
        out.append(f"LIGNE NON AUTORISÉE dans {fid}: {l['desc']} {l['montant']} $ (référence {l['ref']} non approuvée)")
    out.append(f"FACTURÉ LÉGITIME = {facture - sum(l['montant'] for _, l in non_aut)} $")
    for f in L["factures"]:
        out.append(f"{f['id']} ({f['date']}, {f['statut']}) [{f['source']}]: {sum(l['montant'] for l in f['lignes'])} $")
    return "\n".join(out)


def tokens(text: str) -> set[str]:
    """Identifiants (tickets, factures, CR) et dates repérés dans un texte, pour le diff déterministe."""
    return {t.upper() for t in re.findall(r"\b[A-Za-z]{2,4}-\d{1,3}\b", text)} | set(re.findall(r"\d{1,2} (?:octobre|septembre|août|juillet)", text.lower()))
