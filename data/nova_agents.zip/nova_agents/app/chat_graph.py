"""Chat: orchestrateur -> experts (parallèle) -> synthèse -> vérification des citations (code)."""
import operator, re
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from . import kb, llm

REGLES = """Règles:
- Proposition ≠ décision ≠ validation. « Livré / déployé / corrigé » par le fournisseur ≠ validé par le demandeur (sécurité, QA, exploitation).
- Autorité: décision formelle/contrat > ticket/compte rendu > courriel > plan/rapport/registre > chat. À autorité égale, le fait le plus récent l'emporte. Une date de fichier récente ne prouve rien.
- Un brouillon n'est pas approuvé. N'invente ni décision, ni échéance, ni approbation. Si l'information manque, écris « inconnu »."""


class State(TypedDict):
    question: str
    sujets: list[str]
    reponses: Annotated[list[dict], operator.add]
    final: str


def route(state: State):
    liste = "\n".join(f"- {k}: {v}" for k, v in kb.SUJETS.items())
    out = llm.ask_json(f"""Choisis les domaines concernés par cette question sur le projet NOVA. En cas de doute, inclus plus de domaines.
Domaines:
{liste}
Question: {state['question']}
Réponds en JSON: {{"sujets": ["..."]}}""")
    sujets = [s for s in (out.get("sujets", []) if isinstance(out, dict) else []) if s in kb.SUJETS]
    return {"sujets": sujets or list(kb.SUJETS)}


def fan_out(state: State):
    return [Send("expert", {"sujet": s, "question": state["question"]}) for s in state["sujets"]]


def expert(p: dict):
    s = p["sujet"]
    voisins = "\n".join(kb.render(kb.claims_for(v)) for v in kb.VOISINS[s])
    calculs = kb.finance_summary() if s == "finance" else "(sans objet)"
    txt = llm.ask_text(f"""Tu es l'expert « {s} » du projet NOVA ({kb.SUJETS[s]}). Date de référence: 30 septembre 2026, 09 h.
Réponds à la question UNIQUEMENT à partir des faits ci-dessous et cite chaque fait avec sa source entre crochets, ex: [S12].
{REGLES}
Si rien ne concerne ton domaine, réponds exactement: HORS_DOMAINE

Faits de ton domaine:
{kb.render(kb.claims_for(s))}

Faits des domaines voisins (contexte):
{voisins}

Calculs financiers (exacts, faits par le code):
{calculs}

Question: {p['question']}""")
    return {"reponses": [{"sujet": s, "texte": txt}]}


def synthesize(state: State):
    utiles = [r for r in state["reponses"] if "HORS_DOMAINE" not in r["texte"]]
    bloc = "\n\n".join(f"[Expert {r['sujet']}]\n{r['texte']}" for r in utiles) or "(aucune réponse d'expert)"
    final = llm.ask_text(f"""Synthétise en français les réponses des experts pour répondre à la question. Garde les sources [Sxx], les nuances (proposition / décision / validation, livré ≠ validé) et les réserves. Ne rajoute aucun fait. Sois concis.
{REGLES}

Question: {state['question']}

Réponses des experts:
{bloc}""")
    return {"final": final}


def check_citations(state: State):
    """Vérification en code: toute source citée doit exister dans la base."""
    cites = set(re.findall(r"\[(S\d+|N\d+)\]", state["final"]))
    inconnues = sorted(cites - kb.known_sources())
    notes = []
    if not cites:
        notes.append("⚠ aucune source citée")
    if inconnues:
        notes.append(f"⚠ sources inconnues: {', '.join(inconnues)}")
    return {"final": state["final"] + ("\n\n" + " ".join(notes) if notes else "")}


_g = StateGraph(State)
_g.add_node("route", route); _g.add_node("expert", expert); _g.add_node("synthesize", synthesize); _g.add_node("check", check_citations)
_g.add_edge(START, "route")
_g.add_conditional_edges("route", fan_out, ["expert"])
_g.add_edge("expert", "synthesize"); _g.add_edge("synthesize", "check"); _g.add_edge("check", END)
chat_app = _g.compile()


def ask(question: str) -> dict:
    out = chat_app.invoke({"question": question, "reponses": []})
    return {"reponse": out["final"], "sujets": out["sujets"], "experts": out["reponses"]}
