"""Interface web: /  rapport (généré du code, sans LLM) | /chat | /ingest"""
import html, io, json
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from . import kb
from .chat_graph import ask
from .ingest_graph import ingest

app = FastAPI(title="NOVA")
e = html.escape
CSS = """body{font:15px/1.45 system-ui,sans-serif;margin:0;color:#1b1b1b}header{background:#183760;padding:10px 20px}header a{color:#fff;margin-right:16px;text-decoration:none;font-weight:600}
main{padding:14px 20px;max-width:1100px}table{border-collapse:collapse;width:100%;margin-bottom:14px}td,th{border:1px solid #ccc;padding:5px 7px;text-align:left;vertical-align:top}th{background:#eef2f7}
pre{white-space:pre-wrap;background:#f6f7f9;padding:10px;border-radius:6px}textarea,input[type=text]{width:100%;padding:8px;box-sizing:border-box}button{padding:8px 16px;margin-top:8px}.warn{color:#9b1c1c}"""


def page(body: str) -> str:
    return f"""<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>NOVA</title><style>{CSS}</style>
<header><a href="/">Rapport</a><a href="/chat">Chat</a><a href="/ingest">Ajouter des données</a></header><main>{body}</main>"""


def table(head, rows):
    return "<table><tr>" + "".join(f"<th>{e(h)}</th>" for h in head) + "</tr>" + "".join("<tr>" + "".join(f"<td>{e(str(c))}</td>" for c in r) + "</tr>" for r in rows) + "</table>"


@app.get("/", response_class=HTMLResponse)
def rapport():
    base = json.load(open(kb.DATA / "baseline.json", encoding="utf-8"))
    ledger = json.load(open(kb.DATA / "ledger.json", encoding="utf-8"))
    claims = kb.load_claims()
    b = "<h2>Rapport du projet NOVA</h2><p>Baseline: 30 sept 2026, 09 h. Les lignes « à valider » viennent de données ajoutées depuis.</p>"
    b += "<h3>Décisions</h3>" + table(["Date", "Décision", "Source", "Statut"], [(c["date"], c["texte"], c["source"], c.get("statut")) for c in claims if c["type"] == "décision"])
    b += "<h3>Budget (calculé par le code)</h3><pre>" + e(kb.finance_summary()) + "</pre>"
    b += "<h3>Factures</h3>" + table(["Facture", "Date", "Statut", "Total", "Lignes"], [(f["id"], f["date"], f["statut"], sum(l["montant"] for l in f["lignes"]), " | ".join(f"{l['desc']} {l['montant']}" for l in f["lignes"])) for f in ledger["factures"]])
    b += "<h3>Actions restantes</h3>" + table(["ID", "Action", "Responsable", "Statut resp.", "Échéance", "Type"], [(a["id"], a["action"], a["responsable"], a["statut_responsable"], a["echeance"], a["type"]) for a in base["actions"]])
    b += "<h3>Contradictions résolues</h3>" + table(["Sujet", "Conflit", "Résolution", "Critère"], [(c["sujet"], c["conflit"], c["resolution"], c["critere"]) for c in base["contradictions"]])
    b += "<h3>Chronologie</h3>" + table(["Date", "Type", "Événement", "Source", "Statut"], [(c["date"], c["type"], c["texte"], c["source"], c.get("statut")) for c in sorted(claims, key=lambda c: c["date"])])
    return page(b)


@app.get("/chat", response_class=HTMLResponse)
def chat_page():
    return page("""<h2>Chat</h2><input type=text id=q placeholder="Ex: Quelle est la date de production approuvée et pourquoi?" onkeydown="if(event.key=='Enter')go()">
<button onclick=go()>Demander</button><p id=meta></p><pre id=a></pre>
<script>async function go(){a.textContent='...';meta.textContent='';const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q.value})});const j=await r.json();a.textContent=j.reponse;meta.textContent='Experts consultés: '+j.sujets.join(', ')}</script>""")


class Q(BaseModel):
    question: str


@app.post("/api/chat")
def api_chat(q: Q):
    r = ask(q.question)
    return {"reponse": r["reponse"], "sujets": r["sujets"]}


@app.get("/ingest", response_class=HTMLResponse)
def ingest_page():
    return page("""<h2>Ajouter des données</h2><form id=f><p><input type=file name=fichier></p><p>ou coller du texte:</p><textarea name=texte rows=8></textarea>
<button type=submit>Analyser et ajouter</button></form><h3>Rapport d'impacts</h3><pre id=r></pre>
<script>f.onsubmit=async ev=>{ev.preventDefault();r.textContent='Analyse en cours...';const x=await fetch('/api/ingest',{method:'POST',body:new FormData(f)});const j=await x.json();r.textContent=j.rapport+'\\n\\n— '+j.nouveaux.length+' claim(s) ajouté(s) (statut: à valider), source '+j.source}</script>""")


@app.post("/api/ingest")
async def api_ingest(fichier: UploadFile | None = File(None), texte: str = Form("")):
    nom, contenu = "texte_colle", texte
    if fichier is not None and fichier.filename:
        nom, data = fichier.filename, await fichier.read()
        if nom.lower().endswith(".pdf"):
            from pypdf import PdfReader
            contenu = "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)
        else:
            contenu = data.decode("utf-8", errors="replace")
    return ingest(contenu, nom)
