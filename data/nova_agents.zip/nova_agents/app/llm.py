"""Accès au LLM local (Ollama). Seules ces deux fonctions parlent au modèle."""
import json, os, re
from langchain_ollama import ChatOllama

MODEL = os.getenv("NOVA_MODEL", "llama3.1")
# Ollama limite le contexte à 2048 tokens par défaut : on l'augmente, sinon les faits sont tronqués.
_opts = dict(model=MODEL, temperature=0, num_ctx=int(os.getenv("NOVA_NUM_CTX", "8192")))
_text = ChatOllama(**_opts)
_json = ChatOllama(**_opts, format="json")


def ask_text(prompt: str) -> str:
    return _text.invoke(prompt).content.strip()


def ask_json(prompt: str):
    raw = _json.invoke(prompt).content
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        m = re.search(r"[\[{].*[\]}]", raw, re.S)
        return json.loads(m.group(0)) if m else {}
