"""Ingestion: extraction de claims -> diff (code) -> experts concernés (parallèle) -> rapport d'impacts -> ajout à la base."""
import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from . import kb, llm
from .chat_graph import REGLES

TYPES = ["proposition", "décision", "validation", "fait", "signal"]


class State(TypedDict):
    texte: str
    nom: str
    source: str
    nouveaux: list[dict]
    affectes: list[dict]
    sujets: list[str]
    impacts: Annotated[list[dict], operator.add]
    rapport: str


def extract(state: State):
    out = llm.ask_json(f"""Extrais du document les faits du projet NOVA sous forme de claims. N'extrais QUE ce que le document dit explicitement.
Types: proposition (suggéré, à approuver), décision (approbation explicite par une autorité), validation (acceptation par le validateur), fait, signal (problème, risque).
Ne classe en « décision » ou « validation » que si le document le dit clairement; « corrigé / déployé » par le fournisseur est un « fait », pas une validation.
Domaines possibles: {', '.join(kb.SUJETS)}
Réponds en JSON: {{"claims": [{{"sujets": ["..."], "type": "...", "texte": "...", "date": "AAAA-MM-JJ"}}]}}

Document ({state['nom']}):
{state['texte'][:6000]}""")
    items = out.get("claims", []) if isinstance(out, dict) else []
    nouveaux = []
    for c in items:
        txt = str(c.get("texte", "")).strip()
        if not txt:
            continue
        sujets = [s for s in c.get("sujets", []) if s in kb.SUJETS] or kb.detect_sujets(txt)
        nouveaux.append(dict(date=str(c.get("date") or "inconnue"), type=c.get("type") if c.get("type") in TYPES else "fait",
                             texte=txt, sujets=sujets, source=state["source"], fichier=state["nom"], autorite=None, statut="à valider"))
    return {"nouveaux": nouveaux}


def diff(state: State):
    """Déterministe: un claim existant est « affecté » s'il partage un identifiant (ticket, facture, CR, date) avec un nouveau."""
    toks = set().union(*(kb.tokens(c["texte"]) for c in state["nouveaux"])) if state["nouveaux"] else set()
    affectes = [c for c in kb.load_claims() if kb.tokens(c["texte"]) & toks]
    sujets = sorted({s for c in state["nouveaux"] + affectes for s in c["sujets"]})
    return {"affectes": affectes, "sujets": sujets}


def fan_out(state: State):
    return [Send("expert_impact", {"sujet": s, "nouveaux": state["nouveaux"], "affectes": state["affectes"]}) for s in state["sujets"]]


def expert_impact(p: dict):
    s = p["sujet"]
    txt = llm.ask_text(f"""Tu es l'expert « {s} » du projet NOVA ({kb.SUJETS[s]}). Date de référence: 30 septembre 2026.
De nouvelles informations arrivent. Compare-les à tes faits existants.
{REGLES}
Réponds en 3 courtes sections: 1) Ce qui change pour ton domaine; 2) Faits existants affectés (cite leurs sources [Sxx]); 3) Actions à prendre (écris « recommandation » devant toute action qui n'est pas déjà documentée).
Si rien ne concerne ton domaine, réponds exactement: HORS_DOMAINE

Nouveaux claims (non validés):
{kb.render(p['nouveaux'])}

Faits existants de ton domaine:
{kb.render(kb.claims_for(s))}

Faits existants déjà identifiés comme touchés:
{kb.render(p['affectes'])}

Calculs financiers (exacts, faits par le code):
{kb.finance_summary() if s == 'finance' else '(sans objet)'}""")
    return {"impacts": [{"sujet": s, "texte": txt}]}


def report(state: State):
    bloc = "\n\n".join(f"[Expert {i['sujet']}]\n{i['texte']}" for i in state["impacts"] if "HORS_DOMAINE" not in i["texte"]) or "(aucun impact identifié)"
    rapport = llm.ask_text(f"""Rédige en français un rapport d'impacts pour le responsable du projet, avec ces titres: « Ce qui vient de changer », « Informations précédentes affectées », « Actions à prendre », « Ce qui n'a PAS changé ».
{REGLES}
- Ne ferme AUCUNE condition de go-live (validation sécurité SEC-210, fermeture ACC-303, runbook avec rollback approuvé) sans la preuve écrite de son validateur.
- Les nouvelles informations restent « à valider » tant qu'une autorité ne les a pas approuvées.
- Cite les sources [Sxx] ou [{state['source']}]. Sois concis.

Document reçu: {state['nom']}
Synthèse des experts:
{bloc}""")
    return {"rapport": rapport}


def commit(state: State):
    kb.append_claims([dict(c) for c in state["nouveaux"]])  # ajout seulement, statut « à valider »
    return {}


_g = StateGraph(State)
for n, f in [("extract", extract), ("diff", diff), ("expert_impact", expert_impact), ("report", report), ("commit", commit)]:
    _g.add_node(n, f)
_g.add_edge(START, "extract"); _g.add_edge("extract", "diff")
_g.add_conditional_edges("diff", fan_out, ["expert_impact"])
_g.add_edge("expert_impact", "report"); _g.add_edge("report", "commit"); _g.add_edge("commit", END)
ingest_app = _g.compile()


def ingest(texte: str, nom: str) -> dict:
    n = len([s for s in kb.known_sources() if s.startswith("N")]) + 1
    out = ingest_app.invoke({"texte": texte, "nom": nom, "source": f"N{n:02d}", "impacts": []})
    return {"source": out["source"], "rapport": out["rapport"], "nouveaux": out["nouveaux"], "affectes": [c["id"] for c in out["affectes"]]}
