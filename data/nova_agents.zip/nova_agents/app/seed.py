"""Construit data/claims.json depuis la chronologie de la baseline (les réponses QA restent un oracle de test)."""
import json
from . import kb

base = json.loads((kb.DATA / "baseline.json").read_text(encoding="utf-8"))
src = {s["id"]: s for s in base["sources"]}
claims = []
for e in base["chronologie"]:
    s = src[e["source"]]
    if s["pertinence"] in kb.EXCLUS:
        continue
    claims.append(dict(date=e["date"], type=e["type"], texte=e["evenement"], sujets=kb.detect_sujets(e["evenement"] + " " + e["fichier"]),
                       source=e["source"], fichier=e["fichier"], autorite=s["autorite"], statut="baseline"))
kb.CLAIMS.write_text("[]", encoding="utf-8")
kb.append_claims(claims)
print(len(claims), "claims écrits dans", kb.CLAIMS)
