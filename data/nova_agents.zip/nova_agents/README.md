# NOVA agents (LangGraph + Ollama)

## Lancer
```
ollama pull llama3.1
pip install -r requirements.txt
python -m app.seed            # (ré)initialise data/claims.json depuis la baseline
uvicorn app.server:app --reload
```
Pages: `/` rapport (généré du code) | `/chat` | `/ingest` (fichier txt/eml/md/pdf ou texte collé).
Variables: `NOVA_MODEL` (défaut `llama3.1`), `NOVA_NUM_CTX` (défaut 8192; le défaut d'Ollama, 2048, tronque les faits).

## Architecture
- `kb.py`: base de claims en ajout seulement, règles d'autorité et calculs financiers en code, diff par identifiants.
- `chat_graph.py`: route -> 4 experts en parallèle (`Send`) -> synthèse -> vérification des citations (code).
- `ingest_graph.py`: extraction de claims -> diff (code) -> experts touchés en parallèle -> rapport d'impacts -> ajout (statut « à valider »).
- `llm.py`: seul point de contact avec Ollama (`ask_text`, `ask_json`).

## Tests
- `python tests/smoke_test.py`: sans Ollama (faux LLM); vérifie câblage, calculs, citations, ajout seulement, serveur. **Réinitialise ensuite avec `python -m app.seed`** (le test ajoute des claims).
- `python tests/eval_qa.py`: avec Ollama; compare le chat aux réponses de référence Q01-Q10.

## Limites connues (version basique)
- Les claims de départ viennent de la chronologie de la baseline (pas du corpus brut): l'extraction automatique n'est testée que sur les nouveaux documents.
- Repères précis (page, cellule) absents des claims: les citations pointent la source `[Sxx]`.
- `ledger.json` (factures) est saisi à la main; un nouveau document financier n'y est pas ajouté automatiquement.
- Un nouveau document reçoit une autorité « inconnue »; rien n'est validé sans humain.
- llama3.1 (8B) peut mal classer proposition / décision: vérifier l'extraction avant de s'y fier.
