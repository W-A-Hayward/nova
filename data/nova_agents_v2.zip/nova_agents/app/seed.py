"""Construit data/claims.json depuis la baseline (les réponses QA restent un oracle de test, jamais injectées).

Anti-hallucination: la version initiale ne chargeait que 27 événements d'une ligne. Les experts devaient donc
« combler » les trous (qui a approuvé, ce qui reste ouvert, quel document est périmé) avec des inventions.
On charge maintenant tout ce que la baseline établit déjà, avec des drapeaux explicites:
- chronologie (événements datés), en marquant les décisions REMPLACÉES;
- registre des décisions avec leur statut (en vigueur / remplacée / conditionnelle);
- contradictions déjà tranchées (et le critère utilisé) -> le modèle n'a pas à re-trancher;
- actions (en distinguant engagement documenté et simple recommandation);
- note d'analyse de chaque source pertinente, avec avertissement si le document est périmé, brouillon ou historique;
- statut courant de chaque ticket (sert aussi au garde-fou « livré ≠ validé »).
"""
import re
from pathlib import Path
from . import kb

base = kb.baseline()
src = kb.sources()
REF = base["baseline_au"][:10]
claims: list[dict] = []


def add(**c):
    c.setdefault("statut", "baseline")
    c.setdefault("perime", "")
    c["sujets"] = c.get("sujets") or kb.detect_sujets(c["texte"] + " " + c.get("fichier", ""))
    claims.append(c)


AVERT = [(r"(?-i:BROUILLON)", "brouillon: ne vaut ni approbation ni engagement"),  # majuscules seulement: « PJ = CR-04 brouillon » ne rend pas le courriel brouillon
         (r"périmé|NON mis à jour|non mise à jour|OBSOLÈTE|n'a pas été corrigé", "document périmé sur ce point"),
         (r"préparé avant", "préparé avant les dernières vérifications"),
         (r"ne vaut rien|Auteur inconnu", "source non fiable"),
         (r"^Historique", "capture historique: montre un état PASSÉ, pas l'état actuel")]


def avertissement(note: str) -> str:
    return "; ".join(msg for pat, msg in AVERT if re.search(pat, note, re.I))


# 1) Décisions consolidées (statut en vigueur / remplacée)
remplacees = {(d["source"], d["date"]): d["statut"] for d in base["decisions"] if d["statut"].lower().startswith("remplac")}
for d in base["decisions"]:
    add(date=d["date"], type="décision", origine="decision", source=d["source"], fichier=d["fichier"],
        autorite=src[d["source"]]["autorite"], texte=f"Décision {d['id']} du {d['date']}: {d['decision']} — statut au {REF}: {d['statut']}",
        perime=f"décision {d['statut'].lower()}" if (d["source"], d["date"]) in remplacees else "")

# 2) Chronologie
for e in base["chronologie"]:
    s = src[e["source"]]
    if s["pertinence"] in kb.EXCLUS:
        continue
    perime = f"décision {remplacees[(e['source'], e['date'])].lower()}" if e["type"] == "décision" and (e["source"], e["date"]) in remplacees else ""
    add(date=e["date"], type=e["type"], origine="chronologie", texte=e["evenement"], source=e["source"], fichier=e["fichier"],
        autorite=s["autorite"], perime=perime)

# 3) Contradictions déjà tranchées
for k in base["contradictions"]:
    add(date=REF, type="fait", origine="contradiction", source=k["id"], fichier="baseline.json", autorite=None,
        texte=f"Contradiction {k['id']} ({k['sujet']}): {k['conflit']} → tranché: {k['resolution']} (critère: {k['critere']}; statut: {k['statut']})")

# 4) Actions (engagement documenté ≠ recommandation)
for a in base["actions"]:
    add(date=REF, type="signal", origine="action", source=a["id"], fichier="baseline.json", autorite=None,
        texte=f"Action {a['id']}: {a['action']} — responsable: {a['responsable']} (responsable {a['statut_responsable']}); "
              f"échéance: {a['echeance']}; nature: {a['type']}; preuve: {a['preuve']}")

# 5) Notes d'analyse par source + 6) statut des tickets
for s in base["sources"]:
    if s["pertinence"] in kb.EXCLUS:
        continue
    add(date=s["date"], type="fait", origine="note_source", source=s["id"], fichier=s["fichier"], autorite=s["autorite"],
        texte=f"Note sur {s['id']} ({Path(s['fichier']).name}, {s['auteur']}, daté du {s['date']}): {s['note']}",
        perime=avertissement(s["note"]))
    stem = Path(s["fichier"]).stem
    if s["fichier"].startswith("03_Tickets/") and s["fichier"].endswith(".txt") and re.fullmatch(r"[A-Z]+-\d+", stem):
        n = s["note"]
        statut = ("EN VALIDATION" if re.search(r"EN VALIDATION", n, re.I) else
                  "OUVERT" if re.search(r"OUVERT", n, re.I) else
                  "FERMÉ" if re.search(r"Ferm", n, re.I) else "inconnu")
        detail = re.sub(r"^(Fermé|OUVERT|EN VALIDATION)[;,]?\s*", "", n, flags=re.I)
        add(date=REF, type="fait", origine="ticket", source=s["id"], fichier=s["fichier"], autorite=s["autorite"],
            ticket=stem, statut_ticket=statut,
            texte=f"Statut du ticket {stem} au {REF}: {statut}{' (' + detail + ')' if detail else ''}")

# s'exécute aussi à l'import (utilisé par les tests), comme la version initiale
kb.CLAIMS.write_text("[]", encoding="utf-8")
kb.append_claims(claims)
print(len(claims), "claims écrits dans", kb.CLAIMS)
